from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings


class RAGService:

    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(
            model_name="all-MiniLM-L6-v2"
        )

        self.db = FAISS.load_local(
            "rag_pipeline/vector_store",   # ← your correct path
            self.embeddings,
            allow_dangerous_deserialization=True
        )

    def retrieve(self, query: str, k: int = 3):
        results = self.db.similarity_search(query, k=k)
        return [r.page_content for r in results]


# ✅ ADD THIS BELOW (do NOT replace anything above)
def rag_search(query: str):
    rag = RAGService()
    results = rag.retrieve(query)
    return "\n".join(results)