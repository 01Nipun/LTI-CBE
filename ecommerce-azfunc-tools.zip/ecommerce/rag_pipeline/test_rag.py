from rag_service import rag_search

query = "Can I return a laptop?"

result = rag_search(query)

print(result)