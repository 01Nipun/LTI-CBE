from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings


embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
db = FAISS.load_local("vector_store", embeddings, allow_dangerous_deserialization=True)

query = "Can I return a laptop?"
results = db.similarity_search(query, k=2)

for r in results:
    print(r.page_content)