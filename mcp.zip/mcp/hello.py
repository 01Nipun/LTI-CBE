from mcp.server import Server
from mcp.types import TextContent

# Create an MCP server
server = Server(
    name="hello-mcp",
    version="1.0.0"
)

# Define a simple tool
@server.tool()
def greet(name: str = "student"):
    """Return a friendly greeting."""
    return [TextContent(text=f"Hello, {name}! 👋")]

# Start the server
if __name__ == "__main__":
    server.run()
