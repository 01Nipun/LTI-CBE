# server.py
from fastmcp import FastMCP

mcp = FastMCP("basic-mcp")

@mcp.tool
def add_numbers(a: int, b: int) -> int:
    """Adds two integers."""
    return a + b

if __name__ == "__main__":
    print("Starting MCP server...")
    mcp.run()  # default STDIO transport

