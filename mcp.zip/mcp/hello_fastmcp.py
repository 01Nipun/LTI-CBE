from fastmcp import FastMCP

mcp = FastMCP(name="hello-server")

@mcp.tool()
def greet(name: str = "student") -> str:
    """Return a greeting."""
    return f"Hello, {name}! 👋"

if __name__ == "__main__":
    mcp.run()