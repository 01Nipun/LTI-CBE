from mcp.server.fastapi import FastAPIServer
from pydantic import BaseModel

# Create MCP server
app = FastAPIServer()

# Simple tool schema
class HelloInput(BaseModel):
    name: str

# Expose MCP tool
@app.tool()
def hello(input: HelloInput):
    return {"message": f"Hello, {input.name}!"}
