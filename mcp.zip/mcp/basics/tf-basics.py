from transformers import AutoModelForCausalLM, AutoTokenizer

model_name = "mistral/Mistral-7B-v0.1"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)
print("Model loaded successfully!")
