#from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
from fastapi import FastAPI, UploadFile, File, BackgroundTasks
from src.rag_chain import chat_chain
from src.entity_memory import update_entities
from src.ingestion import ingest_text
from src.cache import get_cached_response, store_cached_response

app = FastAPI()


class QueryRequest(BaseModel):

    session_id: str
    query: str


@app.post("/chat")
def chat(request: QueryRequest):

    cached = get_cached_response(request.query)

    if cached:
        return {"response": cached, "cached": True}

    update_entities(request.session_id, request.query)

    response = chat_chain.invoke(
        {
            "query": request.query,
            "session_id": request.session_id
        },
        config={"configurable": {"session_id": request.session_id}}
    )

    store_cached_response(request.query, response)

    return {"response": response, "cached": False}

@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):

    content = await file.read()

    text = content.decode("utf-8")

    chunks = ingest_text(text)

    return {
        "message": "Document ingested",
        "chunks_created": chunks
    }