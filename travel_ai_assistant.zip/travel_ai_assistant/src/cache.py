import redis
import json

from src.config import REDIS_URL

redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=True)


def get_cached_response(query):

    key = f"cache:{query}"

    data = redis_client.get(key)

    if data:
        return json.loads(data)

    return None


def store_cached_response(query, response):

    key = f"cache:{query}"

    redis_client.set(key, json.dumps(response))