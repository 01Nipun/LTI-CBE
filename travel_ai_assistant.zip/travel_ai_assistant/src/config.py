MODEL_NAME = "mistral"
VECTOR_PATH = "vectorstore"
REDIS_URL = "redis://localhost:6379"