from langchain_community.vectorstores import FAISS
from langchain_ollama import OllamaEmbeddings
#from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_text_splitters import RecursiveCharacterTextSplitter
#from langchain.docstore.document import Document
from langchain_core.documents import Document

from src.config import VECTOR_PATH

import os

def load_existing_store():

    #embeddings = OllamaEmbeddings(model="mistral")
    embeddings =  OllamaEmbeddings(model="nomic-embed-text")
    index_path = os.path.join(VECTOR_PATH, "index.faiss")

    if os.path.exists(index_path):

        return FAISS.load_local(
            VECTOR_PATH,
            embeddings,
            allow_dangerous_deserialization=True
        )

    return None
    return None


def ingest_text(text):

    #embeddings = OllamaEmbeddings(model="mistral")
    embeddings =  OllamaEmbeddings(model="nomic-embed-text")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=300,
        chunk_overlap=50
    )

    docs = [Document(page_content=text)]

    chunks = splitter.split_documents(docs)

    vectorstore = load_existing_store()

    if vectorstore:
        vectorstore.add_documents(chunks)
    else:
        vectorstore = FAISS.from_documents(chunks, embeddings)

    vectorstore.save_local(VECTOR_PATH)

    return len(chunks)

if __name__ == "__main__":

    print("Running ingestion script")

    sample_text = """
    Japan is best visited during spring and autumn.
    Italy requires Schengen visa for Indian travelers.
    Thailand has vegetarian food options.
    """

    chunks = ingest_text(sample_text)

    print(f"Created {chunks} chunks and stored in vector DB")