from langchain_community.vectorstores import FAISS
from langchain_community.retrievers import BM25Retriever
from langchain_ollama import OllamaEmbeddings

from src.config import VECTOR_PATH

embeddings = OllamaEmbeddings(model="nomic-embed-text")

vectorstore = FAISS.load_local(
    VECTOR_PATH,
    embeddings,
    allow_dangerous_deserialization=True
)

vector_retriever = vectorstore.as_retriever(search_kwargs={"k":3})

docs = vectorstore.similarity_search("test", k=50)

bm25 = BM25Retriever.from_documents(docs)

bm25.k = 3


def hybrid_search(query):

    vec_docs = vector_retriever.invoke(query)

    bm_docs = bm25.invoke(query)

    combined = vec_docs + bm_docs

    unique = {doc.page_content: doc for doc in combined}

    return list(unique.values())