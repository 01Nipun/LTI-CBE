from langchain.tools import tool


@tool
def weather_tool(city: str):
    """Get current weather for a given city."""

    weather = {
        "Paris": "18°C Cloudy",
        "Tokyo": "22°C Sunny",
        "Rome": "25°C Clear"
    }

    return weather.get(city, "Weather unavailable")


@tool
def travel_cost_tool(destination: str):
    """Estimate travel cost from India to a destination."""

    cost = {
        "Italy": "₹80k - ₹1.2L",
        "Japan": "₹90k - ₹1.5L",
        "Thailand": "₹30k - ₹60k"
    }

    return cost.get(destination, "Cost unavailable")


TOOLS = [weather_tool, travel_cost_tool]