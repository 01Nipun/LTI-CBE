from langchain_ollama import OllamaLLM, OllamaEmbeddings
from langchain_community.vectorstores import FAISS

from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.output_parsers import StrOutputParser

from src.tools import TOOLS
from src.redis_memory import get_session_history
from src.entity_memory import get_entities
from src.config import VECTOR_PATH

from langchain_ollama import ChatOllama

llm = ChatOllama(model="mistral",
    temperature=0,
    num_predict=200
)

llm_with_tools = llm.bind_tools(TOOLS)

#embeddings = OllamaEmbeddings(model="mistral")
embeddings = OllamaEmbeddings(model="nomic-embed-text")

vectorstore = FAISS.load_local(
    VECTOR_PATH,
    embeddings,
    allow_dangerous_deserialization=True
)

#retriever = vectorstore.as_retriever(search_kwargs={"k":3})
from src.hybrid_retriever import hybrid_search
from src.reranker import rerank_documents
def retrieve_docs(inputs):
    query = inputs["query"]
    docs = hybrid_search(query)
    print("Docs before reranking:", len(docs))
    docs = rerank_documents(query, docs)
    print("Docs after reranking:", len(docs))
    return docs
'''
def retrieve_docs(inputs):
    query = inputs["query"]
    return retriever.invoke(query)'''


retrieval = RunnableLambda(retrieve_docs)


def build_prompt(inputs):

    query = inputs["query"]
    context = inputs["context"]
    session_id = inputs["session_id"]

    entities = get_entities(session_id)

    return f"""
You are a helpful travel assistant.

User preferences:
{entities}

Context:
{context}

Question:
{query}
"""


prompt = RunnableLambda(build_prompt)


rag_chain = (

    {
        "context": retrieval,
        "query": RunnablePassthrough(),
        "session_id": RunnablePassthrough()
    }

    | prompt
    | llm_with_tools
    | StrOutputParser()
)


chat_chain = RunnableWithMessageHistory(
    rag_chain,
    get_session_history,
    input_messages_key="query",
    history_messages_key="chat_history"
)