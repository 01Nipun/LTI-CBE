from langchain_ollama import OllamaLLM
from pydantic import BaseModel, Field
from langchain_core.output_parsers import JsonOutputParser

import redis
import json

from src.config import MODEL_NAME, REDIS_URL


# -------------------
# Redis connection
# -------------------

redis_client = redis.Redis.from_url(REDIS_URL, decode_responses=True)


# -------------------
# Entity Schema
# -------------------

class TravelEntities(BaseModel):

    destination: str | None = Field(default=None)
    diet: str | None = Field(default=None)
    budget: str | None = Field(default=None)
    travel_month: str | None = Field(default=None)


parser = JsonOutputParser(pydantic_object=TravelEntities)


# -------------------
# LLM
# -------------------

llm = OllamaLLM(
    model=MODEL_NAME,
    temperature=0
)


# -------------------
# Extract entities
# -------------------

def extract_entities(query: str):

    format_instructions = parser.get_format_instructions()

    prompt = f"""
Extract travel related entities from the query.

Entities:
- destination
- diet
- budget
- travel_month

{format_instructions}

Query:
{query}
"""

    response = llm.invoke(prompt)

    try:
        parsed = parser.parse(response)
        return parsed.dict(exclude_none=True)
    except:
        return {}


# -------------------
# Store entities in Redis
# -------------------

def update_entities(session_id: str, query: str):

    entities = extract_entities(query)

    if not entities:
        return

    redis_key = f"entities:{session_id}"

    existing = redis_client.get(redis_key)

    if existing:
        existing = json.loads(existing)
    else:
        existing = {}

    existing.update(entities)

    redis_client.set(redis_key, json.dumps(existing))


# -------------------
# Retrieve entities
# -------------------

def get_entities(session_id: str):

    redis_key = f"entities:{session_id}"

    data = redis_client.get(redis_key)

    if not data:
        return {}

    return json.loads(data)