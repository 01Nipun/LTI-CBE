# -----------------------------
# ORIGINAL HEAVY RERANKER
# (~90MB model)
# -----------------------------
# from sentence_transformers import CrossEncoder
#
# model = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
#
# def rerank_documents(query, docs, top_k=3):
#     pairs = [[query, doc.page_content] for doc in docs]
#     scores = model.predict(pairs)
#     scored_docs = list(zip(docs, scores))
#     scored_docs.sort(key=lambda x: x[1], reverse=True)
#     return [doc for doc, score in scored_docs[:top_k]]


# --------------------------------
# LIGHTWEIGHT FAST RERANKER
# (~10–15MB)
# --------------------------------

from sentence_transformers import CrossEncoder

model = CrossEncoder("cross-encoder/ms-marco-TinyBERT-L-2-v2")


def rerank_documents(query, docs, top_k=3):

    pairs = [[query, doc.page_content] for doc in docs]

    scores = model.predict(pairs)

    scored_docs = list(zip(docs, scores))

    scored_docs.sort(key=lambda x: x[1], reverse=True)

    return [doc for doc, score in scored_docs[:top_k]]